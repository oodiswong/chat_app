# Django & jQuery Chat Application
This is a very simple chat application made with Django 1.8 and jQuery. Watch the video demonstration on YouTube https://youtu.be/Z8Gjm858CWg. For more queries email me at hasan.mohaiminul@gmail.com
