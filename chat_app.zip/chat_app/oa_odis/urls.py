from django.conf.urls import url

from . import views
from django.conf.urls import url, include
from django.contrib import admin
from rest_framework import routers
from oa_odis.oa_odis_api import Oa_odis_ViewSet

# Routers provide an easy way of automatically determining the URL conf.
router = routers.DefaultRouter()
router.register(r'oa_odis', Oa_odis_ViewSet)

urlpatterns = [
    url(r'^$', views.Home, name='home'),
    url(r'^post/$', views.Post, name='post'),
    url(r'^admin/', admin.site.urls),
]