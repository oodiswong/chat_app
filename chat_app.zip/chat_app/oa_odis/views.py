# coding: utf-8

from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from chatbot import Chat, reflections, multiFunctionCall
import requests, os
from django.views.decorators.csrf import csrf_exempt
from .models import Conversation
import urllib.parse
import subprocess
from threading import Timer
from django.contrib import messages
from pprint import pprint
import os
import pandas as pd
import numpy as np
from scipy import spatial
from gensim.models.doc2vec import Doc2Vec
from nltk.corpus import stopwords
from nltk.tokenize import TweetTokenizer

gbl_username="" 
gbl_pcname="" 
gbl_info=""

class SessionExpiredMiddleware:
    def process_request(request):
        last_activity = request.session['last_activity']
        now = datetime.now()
        print("[class sessionexpiredmiddleware] [process_request]")
        if (now - last_activity).minutes > 10:
            # Do logout / expire session
            # and then...
            return HttpResponseRedirect("LOGIN_PAGE_URL")

        if not request.is_ajax():
            # don't set this for ajax requests or else your
            # expired session checks will keep the session from
            # expiring :)
            request.session['last_activity'] = now
			
class QABot:
    def __init__(self, data, model):
        self.df = data
        self.model = model

    def avg_feature_vector(self, sentence, model, num_features, index2word_set):

        """

        "FUNCTION TO AVERAGE  ALL  OUR FEATURE  VECTORS  IN EVERY DOCUMENT ( QUESTIONS ,IN OUR CASE )"

         sentence: Every set of data .
         model: Convert index2word_set to a set, for speed .
         index2word_set: field holds a list of the working vocabulary .

        """
        words = sentence.split()

        # Pre-initialize an empty numpy array (for speed)
        feature_vec = np.zeros((num_features,), dtype='float32')
        n_words = 0
        for word in words:
            if word in index2word_set:
                n_words += 1
                feature_vec = np.add(feature_vec, model[word])
        if (n_words > 0):
            feature_vec = np.divide(feature_vec, n_words)
        return feature_vec


        ###########################################################################################

    def cosine_dist(self, user_asked):

        """
            COSINE  SIMILARITY  BETWEEN  VECTORS  AND  GIVE PERCENTAGE  OF MATCH  BETWEEN  COMMON QUESTIONS  
            user_asked: users  question asked
            df: preporcessed  dataframe 
            num_features :Word vector dimensionality  
            Index2word:  field holds a list of the working vocabulary
            The model's vocabulary. Convert it to a set, for speed.

        """

        index2word_set = set(self.model.wv.index2word)
        try:
            all_ratios = []
            questn_df = pd.DataFrame({})
            for i in range(self.df.__len__()):
                s1_afv = self.avg_feature_vector(user_asked, model=self.model, num_features=100,
                                                 index2word_set=index2word_set)
                s2_afv = self.avg_feature_vector(self.df['questions'][i], model=self.model, num_features=100,
                                                 index2word_set=index2word_set)
                all_ratios.append(1 - spatial.distance.cosine(s1_afv, s2_afv))
            questn_df = pd.DataFrame({"questions": list(self.df['questions']), "answers": list(self.df['answers']),
                                      "type": list(self.df['type']),
                                      "ratios": all_ratios})
            final_ratio = questn_df.sort_values('ratios', ascending=False)

            if final_ratio.empty:

                return 'sorry  didnt  understand  your question'
            else:

                return final_ratio.head(5)
        except:
            return 'sorry  didnt  understand  your question'


            #############################################################################

    def preprocedd_user_inpt(self, user_asked):
        """
        THIS FUNCTION IS USED  TO  PREPROCESS  OUR  USER INPUT BY REMOVING  STOPWORDS  LIKE "IS" ,"AND" ,"THE" , TOKENIZE  THE  USER INPUT .
         user_asked: user intent 
        """
        a = user_asked.lower()
        stop_words = set(stopwords.words('english'))
        preprocess = []
        tknzr = TweetTokenizer()
        preprocess.append(tknzr.tokenize(a))  ### tokenize  user input
        filtered_sentence = " ".join([w for w in preprocess[0] if not w in stop_words])  ##  remove stopwords
        words = filtered_sentence
        return words


        ################################################################################


def issueIs(query, sessionID="general"):
    print("issueIs "+str(query))
    exec_stmt='exec sp_chatbot_ret'
    sqlcmd_loc='C:\Program Files\Microsoft SQL Server\100\Tools\Binn\sqlcmd'
    sqlcmd_out=subprocess.Popen([r'C:\Program Files\Microsoft SQL Server\100\Tools\Binn\sqlcmd', "-E", "-S", "127.0.0.1", "-d", "btnet", "-Q", exec_stmt], stdout=subprocess.PIPE)
    line_stdout=str(sqlcmd_out.stdout.readlines())
    tmp_stdout=line_stdout.split(",")
    line_total_cnt = len(tmp_stdout)
    line_cnt=0
    stdout=""
    while (line_cnt < line_total_cnt):
       crln_stdout=tmp_stdout[line_cnt].split("\\r\\n")
       actual_stdout=crln_stdout[0].split("b'")
       stdout=stdout+actual_stdout[1]+"<br />"
       line_cnt=line_cnt+1
    #stdout="a<br />b<br />"
    if query[-2] == '?':
        query = "Mr/Ms "+gbl_username+" "+query[:len(query)-2]
    try:
        return 'query:'+stdout
		#send the link to user to click
        #return '<a href="http://www.google.com">www.google.com</a>'
        #return '<a href="file://c:\\8\\joyhome-logo.png">c:\8\joyhome-logo.png</a><br/>'
        #return query
    except:
        pass
    return "Oh, You misspelled somewhere!"


def whoIs(query, sessionID="general"):
    if query[-2] == '?':
        query = query[:len(query)-2]
    try:
        response = requests.get('http://api.stackexchange.com/2.2/tags/' + query + '/wikis?site=stackoverflow')
        data = response.json()
        return data['items'][0]['excerpt']
    except:
        pass
    return "Oh, You misspelled somewhere!"


def results(query, sessionID="general"):
    query_list = query.split(' ')
    query_list = [x for x in query_list if x not in ['posted', 'questions', 'recently', 'recent', 'display', '', 'in', 'of', 'show']]
    # print(query_list)
    if len(query_list) == 1:
        # print('con 1')
        try:
            response = requests.get('https://api.stackexchange.com/2.2/questions?pagesize=5&order=desc&sort=activity&tagged=' + query_list[0] + '&site=stackoverflow')
            data = response.json()
            data_list = [str(i+1)+'. ' + data['items'][i]['title'] for i in range(5)]
            return '<br/>'.join(data_list)
        except:
            pass
    elif len(query_list) == 2 and 'unanswered' not in query_list:
        # print('con 2')
        query_list = sorted(query_list)
        n = query_list[0]
        tag = query_list[1]
        try:
            response = requests.get('https://api.stackexchange.com/2.2/questions?pagesize='+ n +'&order=desc&sort=activity&tagged=' + tag + '&site=stackoverflow')
            data = response.json()
            data_list = [str(i+1)+'. ' + data['items'][i]['title'] for i in range(int(n))]
            return '<br/>'.join(data_list)
        except:
            pass

    else:
        # print('con 3')
        query_list = [x for x in query_list if x not in ['which', 'where', 'whos', 'who\'s' 'is', 'are', 'answered', 'not', 'unanswered', 'for']]
        # print(query_list)
        if len(query_list) ==1:
            try:
                response = requests.get(
                    'https://api.stackexchange.com/2.2/questions/no-answers?pagesize=5&order=desc&sort=activity&tagged=' + query_list[0] + '&site=stackoverflow')
                data = response.json()
                data_list = [str(i+1)+'. ' + data['items'][i]['title'] for i in range(5)]
                return '<br/>'.join(data_list)
            except:
                pass
        elif len(query_list) == 2:
            query_list = sorted(query_list)
            n = query_list[0]
            tag = query_list[1]
            try:
                response = requests.get(
                    'https://api.stackexchange.com/2.2/questions/no-answers?pagesize='+ n +'&order=desc&sort=activity&tagged=' + tag + '&site=stackoverflow')
                data = response.json()
                data_list = [str(i+1)+'. ' + data['items'][i]['title'] for i in range(int(n))]

                return '<br/>'.join(data_list)
            except:
                pass
    return "Oh, You misspelled somewhere!"


#Display recent 3 python questions which are not answered
firstQuestion = "Hi, How may i help you?"

"""
call = multiFunctionCall({"whoIs": whoIs,
                          "issueIs" : issueIs,
                              "results": results})

chat = Chat(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "chatbotTemplate",
                         "Example.template"
                         ),
            reflections, call=call)
"""

def Home(request):
    global gbl_username, gbl_pcname, gbl_info
    print("request["+str(request)+"]")
    gbl_pcname=""
    gbl_username=""
    gbl_info=""

    request.session.set_expiry(60)
    request.session['username'] = gbl_username
    try:
       para=str(request).split("?")
       if (len(para) <= 1):
          print("No parameter provided")
       else:
          para1=para[1].split("'")
          para2=para1[0].split("&")
          ws_cnt=0
          while (ws_cnt < len(para2)):
             if para2[ws_cnt].upper().find("PCNAME") == 0:
                gbl_pcname=para2[ws_cnt].split("=")[1]
             if para2[ws_cnt].upper().find("USERNAME") == 0:
                gbl_username=para2[ws_cnt].split("=")[1]
             if para2[ws_cnt].upper().find("INFO") == 0:
                gbl_info=urllib.parse.unquote(para2[ws_cnt].split("=")[1])
             ws_cnt=ws_cnt+1
    except:
       print("One of the parameter didn't pass in "+para)
	
    #return render(request, "alpha/home.html", {'home': 'active', 'chat': 'chat'} )
    return render(request, "oa_odis/home.html", {'home': 'active'} )


@csrf_exempt
def Post(request):
    global gbl_username, gbl_pcname, gbl_info
    print("Post func "+gbl_username+" "+gbl_pcname+" "+gbl_info)
    
    #while len(chat.conversation["general"])<2:
    #    chat.conversation["general"].append('initiate')
    if request.method == "POST":
        query = request.POST.get('msgbox', None)
        #response = chat.respond(query)
		
        data = pd.read_csv("preprocessed.csv",encoding="ISO-8859-1")  ### Read the preprocessed data  which is saved in local drive .
        model = Doc2Vec.load("doc2vec.model")  ####  import  doc2model model
        data['questions'].fillna("nothing", inplace=True)  ###  filling empty  values  with  'nothing' if present

        Bot = QABot(data, model)         ###Calling the class with data and the model parameters

        userIp = Bot.preprocedd_user_inpt(query)  ######## Calling the  preprocesser  function from class Bot
        predict_question = Bot.cosine_dist(query).iloc[0].answers  #### Calling the cosine_dist function from class Bot

        response = predict_question
        print("query & response " + str(query)+"="+str(response))
        #chat.conversation["general"].append('<br/>'.join(['ME: '+query, 'BOT: '+response]))
        if query.lower() in ['bye', 'quit', 'bbye', 'seeya', 'goodbye']:
            #chat_saved = chat.conversation["general"][2:]
            #response = response + '<br/>' + '<h3>Chat Summary:</h3><br/>' + '<br/><br/>'.join(chat_saved)
            #chat.conversation["general"] = []
            return JsonResponse({'response': response, 'query': query})
        #c = Conversation(query=query, response=response)
        return JsonResponse({'response': response, 'query': query})
    else:
        return HttpResponse('Request must be POST.')

