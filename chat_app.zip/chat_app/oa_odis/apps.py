from django.apps import AppConfig


class Oa_odis_Config(AppConfig):
    name = 'oa_odis'
