from datetime import datetime, timedelta
from django.conf import settings
from django.contrib import auth
import time

class AutoLogout:
    def __init__(self, get_response):        
        self.get_response = get_response
        #print("[middleware][AutoLogout][__init__]"+str(get_response))
        # One-time configuration and initialization.

    def __call__(self, request):
        
        # Code to be executed for each request before
        # the view (and later middleware) are called.

        response = self.get_response(request)
        #print("[middleware][AutoLogout][__call__]"+str(response.content))
        print("[middleware][AutoLogout][__call__]")
        # Code to be executed for each request/response after
        # the view is called.

        if 'last_login' in request.session:
           elapsed = time.time() - request.session['last_login']
           if elapsed > settings.SESSION_IDLE_TIMEOUT:
              del request.session['last_login'] 
              logout(request)
              # flushing the complete session is an option as well!
              # request.session.flush()  
        request.session['last_login'] = time.time()
        return response
		
    def process_request(self, request):
        print("[middleware][AutoLogout][process_request]"+str(request))
        current_datetime = datetime.datetime.now()
        if ('last_login' in request.session):
           last = (current_datetime - request.session['last_login']).seconds
           if last > settings.SESSION_IDLE_TIMEOUT:
              logout(request, login.html)
           else:
              request.session['last_login'] = current_datetime
			  
        return None
