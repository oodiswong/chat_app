from rest_framework import serializers
from .models import oa_odis
from rest_framework import viewsets

class Oa_odis_Serialiser(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = oa_odis
        fields = ('id', 'title', 'description', 'created_at', 'created_by', 'priority')


class Oa_odis_ViewSet(viewsets.ModelViewSet):

    queryset = oa_odis.objects.all()
    serializer_class = Oa_odis_Serialiser
