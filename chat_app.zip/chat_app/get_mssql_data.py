import os
import subprocess

exec_stmt='exec sp_chatbot_ret'
sqlcmd_loc='C:\Program Files\Microsoft SQL Server\100\Tools\Binn\sqlcmd'
sqlcmd_out=subprocess.Popen([r'C:\Program Files\Microsoft SQL Server\100\Tools\Binn\sqlcmd', "-E", "-S", "127.0.0.1", "-d", "btnet", "-Q", exec_stmt], stdout=subprocess.PIPE)
stdout=str(sqlcmd_out.stdout.readlines())
#line_stdout=stdout.split("\r\n")
line_stdout=stdout.split(",")
line_total_cnt = len(line_stdout)
line_cnt=0
#print (stdout)
print (line_total_cnt)
while (line_cnt < line_total_cnt):
    crln_stdout=line_stdout[line_cnt].split("\\r\\n")
    actual_stdout=crln_stdout[0].split("b'")
    print("stdout "+actual_stdout[1])
    line_cnt=line_cnt+1